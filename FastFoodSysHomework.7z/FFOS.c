#include <stdio.h>
#include <string.h>

int main() {
    int choice;
    float totalCost = 0.0;
    int status;
    char size;
    char ingredient;
    float discount = 0.0;
    int addMoreIngredients;
    char promoCode[20];
    int freeItem = 0;

    printf("Welcome to our Fast Food Ordering System :)\n");
    printf("Are you a student or a senior citizen?\n");
    printf("Enter 1 for student, 2 for senior, 0 for others: ");
    scanf("%d", &status);

    if (status == 1) {
        discount = 0.30;
    } else if (status == 2) {
        discount = 0.25;
    }

    printf("Enter promotion code if you have one: ");
    scanf("%s", promoCode);

   if (strcmp(promoCode, "FREEFOOD") == 0) 
   { printf("Congratulations! You've unlocked a free item!\n");
    printf("Choose your free item:\n"); 
    printf("1. Pizza\n"); 
    printf("2. Tacos\n"); 
    printf("3. Salad\n"); 
    printf("Please enter your choice: "); 
    scanf("%d", &freeItem); }

    do {
        printf("Menu:\n");
        printf("1. Pizza (800 DZD)\n");
        printf("2. Tacos (500 DZD)\n");
        printf("3. Salad (600 DZD)\n");
        printf("4. Checkout\n");
        printf("Please enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("You chose Pizza\n");
                printf("Choose size (M for Medium, L for Large, XL for Extra Large): ");
                scanf(" %c", &size);
                printf("You chose size %c\n", size);
                do {
                    printf("Choose ingredient (C for Cheese, B for Beef, T for Tuna, N for None): ");
                    scanf(" %c", &ingredient);
                    if (ingredient != 'N') {
                        printf("You chose ingredient %c\n", ingredient);
                    }
                    printf("Do you want to add more ingredients? (1 for Yes, 0 for No): ");
                    scanf("%d", &addMoreIngredients);
                } while (addMoreIngredients == 1);
                if (!freeItem) {
                    totalCost += 800.0;
                } else {
                    freeItem = 0;
                }
                break;
            case 2:
                printf("You chose Tacos\n");
                printf("Choose size (M for Medium, L for Large, XL for Extra Large): ");
                scanf(" %c", &size);
                printf("You chose size %c\n", size);
                do {
                    printf("Choose ingredient (C for Cheese, B for Beef, T for Tuna, N for None): ");
                    scanf(" %c", &ingredient);
                    if (ingredient != 'N') {
                        printf("You chose ingredient %c\n", ingredient);
                    }
                    printf("Do you want to add more ingredients? (1 for Yes, 0 for No): ");
                    scanf("%d", &addMoreIngredients);
                } while (addMoreIngredients == 1);
                if (!freeItem) {
                    totalCost += 500.0;
                } else {
                    freeItem = 0;
                }
                break;
            case 3:
                printf("You chose Salad\n");
                printf("Choose size (M for Medium, L for Large, XL for Extra Large): ");
                scanf(" %c", &size);
                printf("You chose size %c\n", size);
                do {
                    printf("Choose ingredient (C for Cheese, B for Beef, T for Tuna, N for None): ");
                    scanf(" %c", &ingredient);
                    if (ingredient != 'N') {
                        printf("You chose ingredient %c\n", ingredient);
                    }
                    printf("Do you want to add more ingredients? (1 for Yes, 0 for No): ");
                    scanf("%d", &addMoreIngredients);
                } while (addMoreIngredients == 1);
                if (!freeItem) {
                    totalCost += 600.0;
                } else {
                    freeItem = 0;
                }
                break;
            case 4:
                printf("Checking out...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);
    totalCost -= totalCost * discount;
    printf("Total cost after discount: %.2f DZD\n", totalCost);
    printf("Total cost with tax (19%%): %.2f DZD\n", totalCost * 1.19);
}
