//An algorithm that solves quadratic equations

#include<stdio.h>
#include<math.h>
int main( ) {
float A,B,d,Delta,X1,X2;
printf("enter the values of A,B and d");
scanf("%f",&A);
scanf("%f",&B);
scanf("%f",&d);
Delta=B*B-(4*A*d);
if (Delta<0) printf("there are no solutions");
else if (Delta==0) {X1=-B/2*A;
printf("there is one solution X1=%f",X1);
}
else if (Delta>0) {
X1=(-B+sqrt(Delta))/2*A;
X2=(-B-sqrt(Delta))/2*A;

printf("there are two solution %f\n %f\n",X1,X2);}
}
//By Ouchetati Abdelkarim 