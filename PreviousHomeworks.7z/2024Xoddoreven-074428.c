#include<stdio.h>
int main( ) {
int X;
printf("enter the value of X");
scanf("%d",&X);
if  (X%2== 0) {
printf("X is even");
}
else{
printf("X is odd");
}
}
//by Ouchetati Abdelkarim